package main

import (
	"log"

	"mygoconsumer/controller"

	"github.com/gofiber/fiber/v2"
)

func main() {
	app := fiber.New()

	api := app.Group("/consumerapi")
	api.Get("/consumerusers", controller.GetUsers)
	api.Post("/consumerusers", controller.CreateUser)
	api.Put("/consumerusers/:id", controller.UpdateUser)
	api.Delete("/users/:id", controller.DeleteUser)

	log.Fatal(app.Listen(":8080"))
}
