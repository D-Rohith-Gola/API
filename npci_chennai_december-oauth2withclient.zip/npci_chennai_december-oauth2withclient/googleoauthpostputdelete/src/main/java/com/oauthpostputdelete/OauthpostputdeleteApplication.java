package com.oauthpostputdelete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthpostputdeleteApplication {

	public static void main(String[] args) {
		SpringApplication.run(OauthpostputdeleteApplication.class, args);
	}

}
